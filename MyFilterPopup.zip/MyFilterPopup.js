define([
  "qlik",
  "jquery",
  "css!./MyFilterPopup.css"
], function (qlik, $) {
  "use strict";

  return {
    initialProperties: {
      qInfo: {
        qType: "my-filter-popup"
      },
      props: {
        buttonLabel: "Open Filters",
        popupTitle: "Filters",
        filterId: ""
      }
    },

    definition: {
      type: "items",
      component: "accordion",
      items: {
        settings: {
          uses: "settings",
          items: {
            buttonLabel: {
              ref: "props.buttonLabel",
              label: "Button label",
              type: "string",
              defaultValue: "Open Filters"
            },
            popupTitle: {
              ref: "props.popupTitle",
              label: "Popup title",
              type: "string",
              defaultValue: "Filters"
            },
            filterId: {
              ref: "props.filterId",
              label: "Filter pane Object Id (sheet object)",
              type: "string",
              expression: "optional"
            }
          }
        }
      }
    },

    paint: function ($element, layout) {
      var app = qlik.currApp(this);
      var extId = layout.qInfo.qId;

      var buttonLabel = layout.props.buttonLabel || "Open Filters";
      var popupTitle  = layout.props.popupTitle  || "Filters";
      var filterId    = (layout.props.filterId || "").trim();

      var buttonId    = "filter-popup-btn-" + extId;
      var overlayId   = "filter-popup-overlay-" + extId;
      var windowId    = "filter-popup-window-" + extId;
      var containerId = "filter-popup-container-" + extId;
      var closeId     = "filter-popup-close-" + extId;

      var htmlBtn =
        '<div class="filter-popup-ext">' +
        '  <button id="' + buttonId + '" class="filter-popup-btn">' +
        buttonLabel +
        "  </button>";

      if (!filterId) {
        htmlBtn +=
          '<div style="margin-top:4px;color:red;font-size:11px;">' +
          "Βάλε το Object Id του Filter Pane στις ιδιότητες." +
          "</div>";
      }

      htmlBtn += "</div>";

      $element.html(htmlBtn);

      if ($("#" + overlayId).length === 0) {
        console.log("MyFilterPopup - creating overlay in <body>, overlayId =", overlayId);

        var overlayHtml =
          '<div id="' + overlayId + '" class="filter-popup-overlay" style="display:none;">' +
          '  <div id="' + windowId + '" class="filter-popup-window">' +
          '    <div class="filter-popup-header">' +
          '      <span class="filter-popup-title">' + popupTitle + "</span>" +
          '      <span id="' + closeId + '" class="filter-popup-close">&times;</span>' +
          "    </div>" +
          '    <div id="' + containerId + '" class="filter-popup-body"></div>' +
          "  </div>" +
          "</div>";

        $("body").append(overlayHtml);
      } else {
        $("#" + windowId + " .filter-popup-title").text(popupTitle);
      }

      $("#" + buttonId).off("click").on("click", function () {
        $("#" + overlayId).show();

        var $container = $("#" + containerId);

        $container.html(
          "<div style='padding:8px;font-size:11px;color:#555;'>Φόρτωση φίλτρων...</div>"
        );

        if (!filterId) {
          $container.html(
            "<div style='padding:8px;color:red;'>Δεν έχει οριστεί Filter pane Id.</div>"
          );
          return;
        }

        app.getObject(containerId, filterId)
          .then(function () {
          })
          .catch(function (err) {
            $container.html(
              "<div style='padding:8px;color:red;'>" +
              "Error Loading Filter Pane.<br>" +
              "Check Id <b>" + filterId + "</b> " +
              "</div>"
            );
          });
      });

      $("#" + closeId).off("click").on("click", function (e) {
        e.stopPropagation();
        $("#" + overlayId).hide();
      });

      $("#" + overlayId).off("click").on("click", function (e) {
        if (e.target.id === overlayId) {
          $("#" + overlayId).hide();
        }
      });

      $(document)
        .off("keydown.filterPopup-" + extId)
        .on("keydown.filterPopup-" + extId, function (e) {
          if (e.key === "Escape") {
            $("#" + overlayId).hide();
          }
        });

      return qlik.Promise.resolve();
    }
  };
});
